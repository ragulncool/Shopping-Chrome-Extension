function formfocus() {
	document.getElementById('search-query').focus();
}
window.onload = formfocus;
